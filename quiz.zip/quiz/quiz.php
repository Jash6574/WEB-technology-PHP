<?php
	session_start();

	// Define the correct answers
	$answers = array(
		'q1' => 'b',
		'q2' => 'c'
	);

	// Initialize the score
	if(!isset($_SESSION['score'])) {
		$_SESSION['score'] = 0;
	}

	// Check the answers and update the score
	foreach($answers as $question => $answer) {
		if(isset($_POST[$question]) && $_POST[$question] == $answer) {
			$_SESSION['score']++;
		}
	}

	// Update the progress
	$_SESSION['progress'] = count($_POST);

	// Redirect to the next question or to the results
	if($_SESSION['progress'] < count($answers)) {
		header('Location: quiz.html');
		exit();
	} else {
		header('Location: results.php');
		exit();
	}
?>

